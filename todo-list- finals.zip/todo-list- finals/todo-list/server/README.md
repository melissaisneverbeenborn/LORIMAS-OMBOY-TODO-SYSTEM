# Backend Server Setup

## Quick Start

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Create `.env` file:**
   Copy `.env.example` to `.env` and update with your MySQL credentials:
   ```env
   DB_HOST=localhost
   DB_USER=root
   DB_PASSWORD=
   DB_NAME=todo_app
   JWT_SECRET=your-secret-key-change-this-in-production
   PORT=5000
   ```

3. **Set up the database:**
   - Start XAMPP and ensure MySQL is running
   - Import `database.sql` in phpMyAdmin or run it in MySQL command line

4. **Start the server:**
   ```bash
   npm start
   ```

   For development with auto-reload:
   ```bash
   npm run dev
   ```

The server will run on `http://localhost:5000`

## Environment Variables

- `DB_HOST` - MySQL host (default: localhost)
- `DB_USER` - MySQL username (default: root)
- `DB_PASSWORD` - MySQL password (default: empty)
- `DB_NAME` - Database name (default: todo_app)
- `JWT_SECRET` - Secret key for JWT tokens
- `PORT` - Server port (default: 5000)

