import pool from './db.js';

async function checkSchema() {
  try {
    console.log('📋 Checking todos table structure...\n');
    
    const [columns] = await pool.query(`
      SELECT COLUMN_NAME, COLUMN_TYPE, IS_NULLABLE, COLUMN_DEFAULT
      FROM INFORMATION_SCHEMA.COLUMNS 
      WHERE TABLE_SCHEMA = 'todo_app' 
      AND TABLE_NAME = 'todos'
      ORDER BY ORDINAL_POSITION
    `);
    
    console.log('Columns in todos table:');
    columns.forEach(col => {
      console.log(`  - ${col.COLUMN_NAME}: ${col.COLUMN_TYPE} ${col.IS_NULLABLE === 'YES' ? '(nullable)' : '(not null)'} ${col.COLUMN_DEFAULT ? `default: ${col.COLUMN_DEFAULT}` : ''}`);
    });
    
    console.log('\n✅ Schema check complete!');
    process.exit(0);
  } catch (error) {
    console.error('❌ Error:', error.message);
    process.exit(1);
  }
}

checkSchema();
