import pool from '../db.js';

export const logActivity = async (userId, action, description, todoId = null) => {
  try {
    await pool.execute(
      'INSERT INTO activity_logs (user_id, todo_id, action, description) VALUES (?, ?, ?, ?)',
      [userId, todoId, action, description]
    );
  } catch (error) {
    console.error('Error logging activity:', error);
    // Don't throw - activity logging shouldn't break the main flow
  }
};

