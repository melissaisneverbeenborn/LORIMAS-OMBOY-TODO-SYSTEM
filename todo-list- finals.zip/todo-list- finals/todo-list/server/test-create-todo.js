import pool from './db.js';

async function testCreateTodo() {
  try {
    console.log('🧪 Testing todo creation...\n');
    
    // First, get or create a test user
    let userId;
    const [users] = await pool.query('SELECT id FROM users LIMIT 1');
    
    if (users.length > 0) {
      userId = users[0].id;
      console.log(`Using existing user ID: ${userId}`);
    } else {
      console.log('No users found. Please register a user first.');
      process.exit(1);
    }
    
    // Try to insert a test todo
    const testTodo = {
      user_id: userId,
      title: 'Test Task',
      description: 'This is a test task',
      due_date: '2025-12-31',
      reminder_enabled: 1,
      reminder_at: '2025-12-30 10:00:00',
      completed: 0
    };
    
    console.log('Inserting test todo...');
    const [result] = await pool.execute(
      `INSERT INTO todos (user_id, title, description, due_date, reminder_enabled, reminder_at, completed)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [
        testTodo.user_id,
        testTodo.title,
        testTodo.description,
        testTodo.due_date,
        testTodo.reminder_enabled,
        testTodo.reminder_at,
        testTodo.completed
      ]
    );
    
    console.log(`✅ Todo created successfully with ID: ${result.insertId}`);
    
    // Fetch it back
    const [todos] = await pool.query('SELECT * FROM todos WHERE id = ?', [result.insertId]);
    console.log('\nCreated todo:');
    console.log(todos[0]);
    
    // Clean up
    await pool.query('DELETE FROM todos WHERE id = ?', [result.insertId]);
    console.log('\n✅ Test todo deleted. Test completed successfully!');
    
    process.exit(0);
  } catch (error) {
    console.error('❌ Test failed:', error.message);
    console.error(error);
    process.exit(1);
  }
}

testCreateTodo();
