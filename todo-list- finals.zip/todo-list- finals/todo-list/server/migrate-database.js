import pool from './db.js';

async function migrateDatabase() {
  try {
    console.log('🔄 Starting database migration...');
    
    // Check if reminder_enabled column exists
    const [columns] = await pool.query(`
      SELECT COLUMN_NAME 
      FROM INFORMATION_SCHEMA.COLUMNS 
      WHERE TABLE_SCHEMA = 'todo_app' 
      AND TABLE_NAME = 'todos' 
      AND COLUMN_NAME = 'reminder_enabled'
    `);
    
    if (columns.length === 0) {
      console.log('Adding reminder_enabled column...');
      await pool.query(`
        ALTER TABLE todos 
        ADD COLUMN reminder_enabled TINYINT(1) DEFAULT 0 AFTER due_date
      `);
      console.log('✅ Added reminder_enabled column');
    } else {
      console.log('✓ reminder_enabled column already exists');
    }
    
    // Check if reminder_at column exists
    const [reminderAtColumns] = await pool.query(`
      SELECT COLUMN_NAME 
      FROM INFORMATION_SCHEMA.COLUMNS 
      WHERE TABLE_SCHEMA = 'todo_app' 
      AND TABLE_NAME = 'todos' 
      AND COLUMN_NAME = 'reminder_at'
    `);
    
    if (reminderAtColumns.length === 0) {
      console.log('Adding reminder_at column...');
      await pool.query(`
        ALTER TABLE todos 
        ADD COLUMN reminder_at DATETIME NULL AFTER reminder_enabled
      `);
      console.log('✅ Added reminder_at column');
    } else {
      console.log('✓ reminder_at column already exists');
    }
    
    // Add index for reminder_at if it doesn't exist
    const [indexes] = await pool.query(`
      SHOW INDEX FROM todos WHERE Key_name = 'idx_todos_reminder_at'
    `);
    
    if (indexes.length === 0) {
      console.log('Adding index for reminder_at...');
      await pool.query(`
        CREATE INDEX idx_todos_reminder_at ON todos(reminder_at)
      `);
      console.log('✅ Added index for reminder_at');
    } else {
      console.log('✓ Index for reminder_at already exists');
    }
    
    console.log('\n✅ Database migration completed successfully!');
    process.exit(0);
  } catch (error) {
    console.error('❌ Migration failed:', error.message);
    console.error(error);
    process.exit(1);
  }
}

migrateDatabase();
