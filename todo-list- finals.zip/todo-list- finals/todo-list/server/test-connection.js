import pool from './db.js';

async function testConnection() {
  try {
    console.log('Testing database connection...');
    const connection = await pool.getConnection();
    console.log('✅ Successfully connected to MySQL database');
    
    // Test if tables exist
    const [tables] = await connection.query('SHOW TABLES');
    console.log('\n📋 Available tables:');
    tables.forEach(table => {
      console.log(`  - ${Object.values(table)[0]}`);
    });
    
    connection.release();
    process.exit(0);
  } catch (error) {
    console.error('❌ Database connection failed:', error.message);
    console.error('\nPlease check:');
    console.error('  1. XAMPP MySQL is running');
    console.error('  2. Database "todo_app" exists');
    console.error('  3. .env file has correct credentials');
    process.exit(1);
  }
}

testConnection();
